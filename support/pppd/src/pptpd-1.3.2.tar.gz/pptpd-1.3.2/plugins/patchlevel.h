/* upstream patchlevel.h,v 1.60 2004/01/13 04:46:52 paulus Exp */
/* $Id: patchlevel.h,v 1.4 2005/02/24 01:25:34 quozl Exp $ */

#define VERSION		"2.4.3"
#define DATE		"13 Jan 2004"
