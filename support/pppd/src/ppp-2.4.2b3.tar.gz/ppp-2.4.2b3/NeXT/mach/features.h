/*
 * NeXTStep 3.3 Developer for m68k is missing this file.
 * Some needed headers try to include it:
 *    proc.h includes user.h
 *    user.h includes cpu.h
 *    m68k cpu.h tries in include features.h
 *
 */
