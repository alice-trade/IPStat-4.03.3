/* $Id: patchlevel.h,v 1.57 2003/04/08 13:05:36 paulus Exp $ */

#define VERSION		"2.4.2b3"
#define DATE		"8 April 2003"
