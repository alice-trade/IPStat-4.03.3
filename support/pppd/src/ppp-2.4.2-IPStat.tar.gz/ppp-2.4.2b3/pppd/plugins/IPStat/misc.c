//#include "misc.h"

#include <stdio.h>			// for sprintf
#include <string.h>			// for 
#include <netinet/in.h>		// for ntons, inet_aton
#include <sys/uio.h>
#include <sys/types.h>		// for socket, getsockopt, connect
#include <sys/socket.h>		// for socket, inet_aton, getsockopt, connect
#include <netdb.h>			// for gethostbyname
#include <arpa/inet.h>		// for inet_aton
#include <unistd.h>			// for close
#include <errno.h>
#include <sys/un.h>
#include <stdlib.h>

#include <netinet/ether.h>

#define BUF_SIZE	255

static int connect_with_timeout (int sfd, struct sockaddr *addr, int addrlen, struct timeval *timeout);
static int send_command(int socket, char *command);
static int recv_command(int socket, char *command, size_t len);

int
open_command_socket(const char *name_socket, const char *host, const int port)
{
    int					sock;
	struct timeval 		tv;
    
	if (name_socket == NULL) {
		struct in_addr		addr;
		struct sockaddr_in 	saddr;
		struct hostent 		*hostent;
		char				ip[16];

    	if((sock = socket(PF_INET, SOCK_STREAM, 6)) == -1 ) {
			return -1;
    	}

		if ((hostent = gethostbyname(host))==NULL){
			return -1;
		}
#ifdef HAVE_SNPRINTF
		snprintf(ip, 16, "%d.%d.%d.%d", (unsigned char) hostent->h_addr[0], (unsigned char)hostent->h_addr[1], (unsigned char)hostent->h_addr[2], (unsigned char)hostent->h_addr[3]);
#else
		sprintf(ip, "%d.%d.%d.%d", (unsigned char) hostent->h_addr[0], (unsigned char)hostent->h_addr[1], (unsigned char)hostent->h_addr[2], (unsigned char)hostent->h_addr[3]);
#endif
	
		if (inet_aton(ip, &addr) == 0){
			close(sock);
			return -1;
		}
 	
		saddr.sin_family 		= AF_INET;
		saddr.sin_port			= htons(port);
		saddr.sin_addr.s_addr	= addr.s_addr;
	
		tv.tv_sec = 0;
		tv.tv_usec = 100;
	
		if (connect_with_timeout(sock, (struct sockaddr*)&saddr, sizeof(saddr), &tv) == -1){
			close(sock);
			return -1;
		}
	} else {
		struct sockaddr_un  saddr;
			
		if ((sock = socket(AF_UNIX, SOCK_STREAM, 0)) == -1 ) {
        	    return -1;
		}

		saddr.sun_family = AF_UNIX;
    		strncpy(saddr.sun_path, name_socket, 50);
		if (connect(sock, (struct sockaddr*)&saddr, sizeof(saddr)) == -1) {
			return -1;
		}
    }
                                                                                
    return sock;
}

int
close_command_socket(int sock)
{
	close(sock);
	return 1;
}

int 
send_msg(int sock, char *msg)
{
	int ret;
	
loop:
	ret = send(sock, msg, strlen(msg), 0);
	
	if (ret == -1) {
		if (errno == EINTR) goto loop;
		return -1;
	}
	
	if (ret != strlen(msg)) return -1;
	return ret;
}

int 
recv_msg(int sock, char *msg, size_t len)
{
	int ret;
	
loop:
	ret = recv(sock, msg, len, 0);
	
	if (ret == -1) {
		if (errno == EINTR) goto loop;
		return -1;
	}
	
	return ret;
}


static int 
connect_with_timeout (int sfd, struct sockaddr *addr, int addrlen, struct timeval *timeout)
{
    struct timeval sv;
    int svlen = sizeof(sv);
    int ret;

    if (!timeout) return connect (sfd, addr, addrlen);
    if (getsockopt (sfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&sv, &svlen) < 0) return -1;
    if (setsockopt (sfd, SOL_SOCKET, SO_RCVTIMEO, (char *)timeout, sizeof *timeout) < 0) return -1;
    ret = connect (sfd, addr, addrlen);
    setsockopt (sfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&sv, sizeof sv);
    return ret;
}

int
ip2host(uint32_t ip, char *host)
{
    struct in_addr tmp_ip;
	                                                                                                                                                             
    if (host == NULL) return 0;
    tmp_ip.s_addr = ip;
    sprintf(host, "%s", inet_ntoa(tmp_ip));
    return 1;
}


uint32_t
host2ip(char *host)
{
    unsigned long l;
    unsigned int val;
    int i;

    l = 0;
    for (i = 0; i < 4; i++) {
	l <<= 8;
	if (*host != '\0') {
	    val = 0;
	    while (*host != '\0' && *host != '.') {
		val *= 10;
		val += *host - '0';
		host++;
	    }
	    l |= val;
	    if (*host != '\0') host++;
	}
    }
    return(htonl(l));
}

int
exec_prog(const char *name, const char *path, char *var[])
{
    pid_t   pid = fork();
    int     status;
    pid_t   w_pid;
		                                                                                                                                                             
    if (pid == (pid_t) -1) {
        fprintf(stderr, "error fork (%s)\n", strerror(errno));
        _exit(1);
    } else if (pid == 0) {
	char tmp[FILENAME_MAX]="";
	
	sprintf(tmp, "%s/%s", path, name);
        execvp(tmp, var);
        fprintf(stderr, "error execvp (%s)\n", strerror(errno));
        _exit(1);
    } else {
        status = 0;
        for(;;) {
            w_pid = waitpid(pid, &status, 0);
            if (w_pid > 0) break;
            if( w_pid == -1 && errno == EINTR )  continue;
            if( pid < 0)  break;
        }
    }
    return status;
}

void 
ip2mac1(char *ip, char *mac)
{
    char 		*buf;
    char 		b_ip[32], b_hw[32], b_trash[32];
    FILE 		*arp;

    bzero(mac, 18);
    
    if ((buf = (char*)malloc(256)) == NULL) return;
    arp = fopen("/proc/net/arp", "rt");
    if (arp == NULL) { 
	fprintf(stderr, "failed to open /proc/net/arp\n"); 
	return; 
    }
    if (!fgets(buf, 255, arp)) return;
    while (!feof(arp)) {
        if (!fgets(buf, 255, arp)) break;
        bzero(b_ip, 32); bzero(b_hw, 32);
        sscanf(buf, "%s%s%s%s", b_ip, b_trash, b_trash, b_hw);
	if (strncmp(ip, b_ip, 15)==0) {
	    int i;
	    
	    for (i=0;i<17;i++) b_hw[i]=tolower(b_hw[i]);
	    strncpy(mac, b_hw, 18);	    
	}
    }
    free(buf);
}
