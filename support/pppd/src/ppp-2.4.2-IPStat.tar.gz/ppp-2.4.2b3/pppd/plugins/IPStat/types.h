/*
  (C) 2001-2004 Kukuev Dmitry aka Kornet [kornet@perm.ru]
*/

#ifndef _TYPES_H
#define _TYPES_H 1

#ifndef FALSE
#define FALSE 0
#undef TRUE
#define TRUE !FALSE
#endif

#include <arpa/inet.h>

#define _DEBUG
#define _MAX_QUERY_BUFFER	1024
#define _MAX_LENGTH_BUFFER	1024
#define _MAX_LENGTH_LOGIN	50
#define _MAX_LENGTH_PASSWD	50
#define _MAX_LENGTH_MAC		18
#define _MAX_LENGTH_IP		16
#define _MAX_LENGTH_SID		33
#define _MAX_LENGTH_MD5		33

#define LENGTH_MSG		2048
//--------------------------------------

#endif /* types.h */
