
static char const RCSID[] =
"$Id: ipstat.c,v 1.5 2006/01/28 11:35:36 kornet Exp $";

#include "pppd.h"
#include "chap.h"
#ifdef CHAPMS
#include "chap_ms.h"
#ifdef MPPE
#include "md5.h"
#endif
#endif
#include "fsm.h"
#include "ipcp.h"
#include <syslog.h>
#include <sys/types.h>
#include <sys/time.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <stdio.h>

#include "misc.h"
#include "libxml.h"
#include "types.h"

#define BUF_LEN 1024

#define false 0
#define true ! false

static char *request_socket = NULL;
static char *path_to_scripts = NULL;
static char *ipstat_debug = NULL;

static option_t Options[] = {
    { "ipstat-request-socket", o_string, &request_socket },
    { "ipstat-path-to-scripts", o_string, &path_to_scripts },
    { "ipstat-debug", o_string, &ipstat_debug },
    { NULL }
};

static int 	ipstat_secret_check(void);
static int 	ipstat_pap_auth(char *user, char *passwd, char **msgp, struct wordlist **paddrs,  struct wordlist **popts);
static int 	ipstat_chap_auth(char *user, u_char *remmd, int remmd_len,  chap_state *cstate);

static void 	ipstat_ip_up(void *opaque, int arg);
static void 	ipstat_ip_down(void *opaque, int arg);
static int 	ipstat_init(char *msg);
static int 	ipstat_allowed_address(u_int32_t addr);
static void 	radius_choose_ip(u_int32_t *addrp);
static int	ipstat_setparams(char *buffer);
static void	ipstat_interim(void *ignored);

struct ipstat_state {
    int accounting_started;
    int initialized;
    int client_port;
    int choose_ip;
    int any_ip_addr_ok;
    int done_chap_once;
    u_int32_t ip_addr;
    char user[50];
    char request_socket[MAXPATHLEN];
    char path_to_scripts[MAXPATHLEN];
    int ipstat_debug;
    time_t start_time;
    int socket;
    char SID[33];
    char mac[18];
};

/* The pre_auth_hook MAY set authserver and acctserver if it wants.
   In that case, they override the values in the radiusclient.conf file */


static struct ipstat_state rstate;

char pppd_version[] = VERSION;

void
plugin_init(void)
{
    pap_check_hook = ipstat_secret_check;
    pap_auth_hook = ipstat_pap_auth;

    chap_check_hook = ipstat_secret_check;
    chap_auth_hook = ipstat_chap_auth;
    
    ip_choose_hook = radius_choose_ip;
    
    allowed_address_hook = ipstat_allowed_address;

    add_notifier(&ip_up_notifier, ipstat_ip_up, NULL);
    add_notifier(&ip_down_notifier, ipstat_ip_down, NULL);

    memset(&rstate, 0, sizeof(rstate));

    strlcpy(rstate.request_socket, "/opt/IPStat/tmp/ipstat_pppd.socket", sizeof(rstate.request_socket));
    strlcpy(rstate.path_to_scripts, "/opt/IPStat/bin", sizeof(rstate.path_to_scripts));
    rstate.ipstat_debug = 1;
    
    add_options(Options);

    info("IPStat plugin initialized.");
    info("     Request socket: %s", rstate.request_socket);
    info("     Path to scripts: %s", rstate.path_to_scripts);
}

static int
ipstat_init(char *msg)
{
    if (rstate.initialized) {
	return 0;
    }

    if (request_socket && *request_socket) {
		strlcpy(rstate.request_socket, request_socket, MAXPATHLEN-1);
    }
    if (path_to_scripts && *path_to_scripts) {
		strlcpy(rstate.path_to_scripts, path_to_scripts, MAXPATHLEN-1);
    if (ipstat_debug && *ipstat_debug) {
     if (strncmp(ipstat_debug, "yes", 3)==0) rstate.ipstat_debug = 1;
     else				    rstate.ipstat_debug = 0; 
     }
    }


    bzero(rstate.SID, _MAX_LENGTH_SID);
    bzero(rstate.mac, _MAX_LENGTH_MAC);
    
    rstate.choose_ip = 0;
    rstate.initialized = 1;

    return 0;
}


static void
radius_choose_ip(u_int32_t *addrp)
{
    if (rstate.choose_ip) {
        *addrp = rstate.ip_addr;
    }else rstate.ip_addr = *addrp;
}

static int
ipstat_secret_check(void)
{
    return 1;
}

static void
connect_time_expired(arg)
    void *arg;
{
    if (rstate.ipstat_debug) info("Connect time expired");
    lcp_close(0, "Connect time expired");	/* Close connection */
    status = EXIT_CONNECT_TIME;
}

#ifdef MAXOCTETS
static void
check_maxoctets(arg)
    void *arg;
{
    int diff;
    unsigned int used;

    update_link_stats(ifunit);
    link_stats_valid=0;
    
    switch(maxoctets_dir) {
	case PPP_OCTETS_DIRECTION_IN:
	    used = link_stats.bytes_in;
	    break;
	case PPP_OCTETS_DIRECTION_OUT:
	    used = link_stats.bytes_out;
	    break;
	case PPP_OCTETS_DIRECTION_MAXOVERAL:
	case PPP_OCTETS_DIRECTION_MAXSESSION:
	    used = (link_stats.bytes_in > link_stats.bytes_out) ? link_stats.bytes_in : link_stats.bytes_out;
	    break;
	default:
	    used = link_stats.bytes_in+link_stats.bytes_out;
	    break;
    }
    diff = maxoctets - used;
    if(diff < 0) {
	notice("Traffic limit reached. Limit: %u Used: %u", maxoctets, used);
	lcp_close(0, "Traffic limit");
	need_holdoff = 0;
	status = EXIT_TRAFFIC_LIMIT;
    } else {
        TIMEOUT(check_maxoctets, NULL, maxoctets_timeout);
    }
}
#endif


static int
ipstat_pap_auth(char *user, char *passwd, char **msgp, struct wordlist **paddrs, struct wordlist **popts)
{
    int 		result;
    static char 	radius_msg[BUF_LEN];
    int 		socket = -1;
    XML_SESSION		*sid;
    char		msg[LENGTH_MSG];
    int			ret;
    char		error_code[5], error_mesage[1024] = "", t_password[_MAX_LENGTH_PASSWD]="";
    struct ether_addr	e;
    
    radius_msg[0] = 0;
    *msgp = radius_msg;

    if (ipstat_init(radius_msg) < 0) {
		return 0;
    }
    
    ip2mac1(ipparam, rstate.mac);

//    if (rstate.ipstat_debug) info("connect client: ip=%s mac=%s", remote_number, rstate.mac);

    if ((sid = tree_init())==NULL) {
	sprintf(radius_msg, "Permission denied - error create xml tree");
	error("User %s: permission denied - error create xml tree", user);
	return 0;
    }
    
    tree_addnode(sid, "cmd", "auth");
    tree_addnode(sid, "login", user);
    if (*rstate.mac) tree_addnode(sid, "mac", rstate.mac);
    if (*ipparam) tree_addnode(sid, "remote_number", ipparam);
    tree_getxml(sid, msg, LENGTH_MSG);
    tree_free(sid);
    info("xml=(%s)", msg);
    if ((socket = open_command_socket(rstate.request_socket, NULL, 0)) == -1) {
	sprintf(radius_msg, "Permission denied - error open socket");
	error("User %s: permission denied - error open socket", user);
	return 0;
    }
    
    if (send_msg(socket, msg) == -1) {
	sprintf(radius_msg, "Permission denied - error send to socket");
	error("User %s: permission denied - error send to socket", user);
	close_command_socket(socket);
	return 0;
    }
    
    bzero(msg, LENGTH_MSG);
    if (recv_msg(socket, msg, LENGTH_MSG) == -1) {
	sprintf(radius_msg, "Permission denied - error recv from socket");
	error("User %s: permission denied - error recv from socket", user);
	close_command_socket(socket);
	return 0;
    }
    
    if ((sid = xpath_init(msg)) == false) {
	sprintf(radius_msg, "Permission denied - error init xpath");
	error("User %s: permission denied - error init xpath", user);
	close_command_socket(socket);
	return 0;
    }
    
    if (xpath_get_param(sid, "error_code", error_code, 4) == false) {
	sprintf(radius_msg, "Permission denied - not found result code");
	error("User %s: permission denied - not found result code", user);
	close_command_socket(socket);
	return 0;
    }
    
    if (strncmp(error_code, "ERR", 3) == 0) {
	xpath_get_param(sid, "message", error_mesage, 1024);
	strncpy(radius_msg, error_mesage, 1024);
        error("User %s: %s", user, error_mesage);
	close_command_socket(socket);
        return 0;
    }

    if (xpath_get_param(sid, "password", t_password, _MAX_LENGTH_PASSWD) == false) {
	sprintf(radius_msg, "Permission denied - not found password");
	error("User %s: permission denied - not found password", user);
	close_command_socket(socket);
	return 0;
    }
    
    close_command_socket(socket);

    if (strncmp(passwd, t_password, _MAX_LENGTH_PASSWD-1)!=0) {
	char 	*argv[4];
        char	message[255];
	int 	status;

	sprintf(radius_msg, "Permission denied - password not correct");
	error("User %s: permission denied - password not correct", user);

	sprintf(message, "������ �����ݣ�: ������������ %s ���������� �������� ������ (ip=%s, mac=%s)", user, passwd, ipparam, rstate.mac);
	argv[0]  = strdup("send_notify.sh");
        argv[1]  = strdup(message);
	argv[2]  = NULL;
	
	status = exec_prog("send_notify.sh", rstate.path_to_scripts, argv);
	free(argv[1]);
	free(argv[0]);
	    
	if (status != 0 ) error("error send notify");
	else if (rstate.ipstat_debug) info("send notify - success");
        return 0;    
    }
    
    if ((sid = tree_init())==NULL) {
	sprintf(radius_msg, "Permission denied - error create xml tree");
	error("User %s: permission denied - error create xml tree", user);
	return 0;
    }
    
    tree_addnode(sid, "cmd", "autz");
    tree_addnode(sid, "login", user);
    tree_getxml(sid, msg, LENGTH_MSG);
    tree_free(sid);

    if ((socket = open_command_socket(rstate.request_socket, NULL, 0)) == -1) {
	sprintf(radius_msg, "Permission denied - error open socket");
	error("User %s: permission denied - error open socket", user);
	return 0;
    }

    if (send_msg(socket, msg) == -1) {
	sprintf(radius_msg, "Permission denied - error send to socket");
	error("User %s: permission denied - error send to socket", user);
	close_command_socket(socket);
	return 0;
    }
    
    bzero(msg, LENGTH_MSG);
    if (recv_msg(socket, msg, LENGTH_MSG) == -1) {
	sprintf(radius_msg, "Permission denied - error recv from socket");
	error("User %s: permission denied - error recv from socket", user);
	close_command_socket(socket);
	return 0;
    }
    
    if (!ipstat_setparams(msg)) {
	sprintf(radius_msg, "Permission denied - error setparam");
	error("User %s: permission denied - error setparam", user);
	close_command_socket(socket);
	return 0;
    }
    
    close_command_socket(socket);
    return 1;
}


static int
ipstat_chap_auth(char *user, u_char *remmd, int remmd_len, chap_state *cstate)
{
    static char 	radius_msg[BUF_LEN];
    int 		code = CHAP_FAILURE;
    char 		secret[255];
    char 		msgerr[255];
    int			secret_len;
    MD5_CTX 		mdContext;
    u_char 		hash[MD5_SIGNATURE_SIZE];
    int 		socket = -1;
    XML_SESSION		*sid;
    char		msg[LENGTH_MSG];
    int			ret;
    char		error_code[5], error_mesage[1024] = "", t_password[_MAX_LENGTH_PASSWD]="";
    struct ether_addr	e;
                                                                                                                                                                     
    radius_msg[0] = 0;

    if (ipstat_init(radius_msg) < 0) {
		return 0;
    }

    ip2mac1(ipparam, rstate.mac);

//    if (rstate.ipstat_debug) info("connect client: ip=%s mac=%s", remote_number, rstate.mac);

    if ((sid = tree_init())==NULL) {
	sprintf(radius_msg, "Permission denied - error create xml tree");
	error("User %s: permission denied - error create xml tree", user);
	return CHAP_FAILURE;
    }
    
    tree_addnode(sid, "cmd", "auth");
    tree_addnode(sid, "login", user);
    if (*rstate.mac) tree_addnode(sid, "mac", rstate.mac);
    if (*ipparam) tree_addnode(sid, "remote_number", ipparam);
    tree_getxml(sid, msg, LENGTH_MSG);
    tree_free(sid);

    if (rstate.ipstat_debug) info("xml=(%s)", msg);

    if ((socket = open_command_socket(rstate.request_socket, NULL, 0)) == -1) {
	sprintf(radius_msg, "Permission denied - error open socket");
	error("User %s: permission denied - error open socket", user);
	return CHAP_FAILURE;
    }
    
    if (send_msg(socket, msg) == -1) {
	sprintf(radius_msg, "Permission denied - error send to socket");
	error("User %s: permission denied - error send to socket", user);
	close_command_socket(socket);
	return CHAP_FAILURE;
    }
    
    bzero(msg, LENGTH_MSG);
    if (recv_msg(socket, msg, LENGTH_MSG) == -1) {
	sprintf(radius_msg, "Permission denied - error recv from socket");
	error("User %s: permission denied - error recv from socket", user);
	close_command_socket(socket);
	return CHAP_FAILURE;
    }
    
    if (rstate.ipstat_debug) info("result=%s", msg);
    
    if ((sid = xpath_init(msg)) == false) {
	sprintf(radius_msg, "Permission denied - error init xpath");
	error("User %s: permission denied - error init xpath", user);
	close_command_socket(socket);
	return CHAP_FAILURE;
    }
    
    if (xpath_get_param(sid, "error_code", error_code, 4) == false) {
	sprintf(radius_msg, "Permission denied - not found result code");
	error("User %s: permission denied - not found result code", user);
	close_command_socket(socket);
	return CHAP_FAILURE;
    }
    
    if (strncmp(error_code, "ERR", 3) == 0) {
	xpath_get_param(sid, "message", error_mesage, 1024);
	strncpy(radius_msg, error_mesage, BUF_LEN);
        error("User %s: %s", user, error_mesage);
	close_command_socket(socket);
        return CHAP_FAILURE;
    }

    if (xpath_get_param(sid, "password", secret, _MAX_LENGTH_PASSWD) == false) {
	sprintf(radius_msg, "Permission denied - not found password");
	error("User %s: permission denied - not found password", user);
	close_command_socket(socket);
	return CHAP_FAILURE;
    }
    close_command_socket(socket);

    if (!*secret) {
	error("user %s not found", user);
        return CHAP_FAILURE;
    }
    
    secret_len = strlen(secret);

    if (ipstat_init(radius_msg) < 0) {
		error("%s", radius_msg);
		return CHAP_FAILURE;
    }

/*  generate MD based on negotiated type */
    switch (cstate->chal_type) {
        case CHAP_DIGEST_MD5:
		if (remmd_len != MD5_SIGNATURE_SIZE) break;
		MD5Init(&mdContext);
		MD5Update(&mdContext, &cstate->chal_id, 1);
		MD5Update(&mdContext, secret, secret_len);
		MD5Update(&mdContext, cstate->challenge, cstate->chal_len);
		MD5Final(hash, &mdContext);
		
		if (memcmp(hash, remmd, MD5_SIGNATURE_SIZE) == 0)  code = CHAP_SUCCESS;
		break;
#ifdef CHAPMS
	case CHAP_MICROSOFT:
	{
		int response_offset, response_size;
		MS_ChapResponse *rmd = (MS_ChapResponse *) remmd;
		MS_ChapResponse md;

		if (remmd_len != MS_CHAP_RESPONSE_LEN)  break;

		if (rmd->UseNT[0]) {
		    response_offset = offsetof(MS_ChapResponse, NTResp);
		    response_size = sizeof(rmd->NTResp);
		} else {
#ifdef MSLANMAN
		    response_offset = offsetof(MS_ChapResponse, LANManResp);
		    response_size = sizeof(rmd->LANManResp);
#else
		    notice("Peer request for LANMAN auth not supported");
		    break;
#endif /* MSLANMAN */
		}

		ChapMS(cstate, cstate->challenge, secret, secret_len, &md);

		if (memcmp((u_char *) &md + response_offset,
			   (u_char *) remmd + response_offset,
			   response_size) == 0)
		    code = CHAP_SUCCESS;
		break;
	}

	case CHAP_MICROSOFT_V2:
	{
		MS_Chap2Response *rmd = (MS_Chap2Response *) remmd;
		MS_Chap2Response md;

		if (remmd_len != MS_CHAP2_RESPONSE_LEN) break;

		ChapMS2(cstate, cstate->challenge, rmd->PeerChallenge,
			user,
			secret, secret_len, &md,
			cstate->saresponse, MS_CHAP2_AUTHENTICATOR);

		if (memcmp(md.NTResp, rmd->NTResp, sizeof(md.NTResp)) == 0)
		    code = CHAP_SUCCESS;
		break;
	}
#endif /* CHAPMS */
	default:
		CHAPDEBUG(("unknown digest type %d", cstate->chal_type));
    }
    if (code != CHAP_SUCCESS) {
    	char 	*argv[4];
        char	message[255];
	int	status;

	sprintf(message, "������ �����ݣ�: ������������ %s ���������� �������� ������ (ip=%s, mac=%s)", user, ipparam, rstate.mac);
	argv[0]  = strdup("send_notify.sh");
        argv[1]  = strdup(message);
	argv[2]  = NULL;
	status = exec_prog("send_notify.sh", rstate.path_to_scripts, argv);
	free(argv[1]);
	free(argv[0]);
	    
	if (status != 0 ) error("error send notify");
	else if (rstate.ipstat_debug) info("send notify - success");

	return CHAP_FAILURE;
    }
    
    if ((sid = tree_init())==NULL) {
	sprintf(radius_msg, "Permission denied - error create xml tree");
	error("User %s: permission denied - error create xml tree", user);
	return 0;
    }
    
    tree_addnode(sid, "cmd", "autz");
    tree_addnode(sid, "login", user);
    tree_getxml(sid, msg, LENGTH_MSG);
    tree_free(sid);

    if ((socket = open_command_socket(rstate.request_socket, NULL, 0)) == -1) {
	sprintf(radius_msg, "Permission denied - error open socket");
	error("User %s: permission denied - error open socket", user);
	return 0;
    }

    if (send_msg(socket, msg) == -1) {
	sprintf(radius_msg, "Permission denied - error send to socket");
	error("User %s: permission denied - error send to socket", user);
	close_command_socket(socket);
	return 0;
    }
    
    if (recv_msg(socket, msg, LENGTH_MSG) == -1) {
	sprintf(radius_msg, "Permission denied - error recv from socket");
	error("User %s: permission denied - error recv from socket", user);
	close_command_socket(socket);
	return 0;
    }
    
    if (!ipstat_setparams(msg)) {
	sprintf(radius_msg, "Permission denied - error setparam");
	error("User %s: permission denied - error setparam", user);
	close_command_socket(socket);
	return 0;
    }
    
    close_command_socket(socket);
    
    return code;
}

static void
ipstat_ip_up(void *opaque, int arg)
{
    XML_SESSION	*sid;
    int 	socket;
    char 	ip[_MAX_LENGTH_IP];
    char 	msgerr[255];
    char	msg[LENGTH_MSG];
    
    int		ret;

    int 	status;
    char 	*argv[4], t[50];
    
    
    if (rstate.ipstat_debug) info("ip up, %x", rstate.ip_addr);

    if ((sid = tree_init())==NULL) {
	lcp_close(0, "User %s: permission denied - error create xml tree", user);	/* Close connection */
	status = EXIT_FATAL_ERROR;
	return;
    }
    tree_addnode(sid, "cmd", "start");
    tree_addnode(sid, "session_id", rstate.SID);
    sprintf(t, "%u", rstate.ip_addr);
    tree_addnode(sid, "framed_address", t);
    if (*rstate.mac) tree_addnode(sid, "mac", rstate.mac);
    if (*ipparam) tree_addnode(sid, "remote_number", ipparam);
    
    tree_getxml(sid, msg, LENGTH_MSG);
    tree_free(sid);

    if ((socket = open_command_socket(rstate.request_socket, NULL, 0)) == -1) {
	lcp_close(0, "User %s: permission denied - error open socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    if (send_msg(socket, msg) == -1) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error send to socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    bzero(msg, LENGTH_MSG);
    if (recv_msg(socket, msg, LENGTH_MSG) == -1) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error recv to socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    if (!ipstat_setparams(msg)) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error setparam", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    close_command_socket(socket);

    argv[0]  = strdup("iface_up.sh");
    argv[1]  = strdup(ifname);
    argv[2]  = NULL;
    status = exec_prog("iface_up.sh", rstate.path_to_scripts, argv);
    free(argv[1]);
    free(argv[0]);
    
    if (status == 0 ) info("script running 'iface_up.sh' - success");
    else error("script running 'iface_up.sh' - error");

    TIMEOUT(ipstat_interim, NULL, 60);
}

static void
ipstat_ip_down(void *opaque, int arg)
{
    XML_SESSION	*sid;
    ipcp_options *ho = &ipcp_hisoptions[0];
    int 	socket, ret;
    char 	ip[18];
    char 	msgerr[255];
    char	msg[LENGTH_MSG];
    int 	status;
    char 	*argv[4], t[50];
    
    
    if (rstate.ipstat_debug) info("ip down, %x", rstate.ip_addr);

    if ((sid = tree_init())==NULL) {
	lcp_close(0, "User %s: permission denied - error create xml tree", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }
    
    tree_addnode(sid, "cmd", "stop");
    tree_addnode(sid, "session_id", rstate.SID);

    sprintf(t, "%u", rstate.ip_addr);
    tree_addnode(sid, "framed_address", t);
    if (*rstate.mac) tree_addnode(sid, "mac", rstate.mac);
    if (*ipparam) tree_addnode(sid, "remote_number", ipparam);

    update_link_stats(0);
    if (link_stats_valid) {    
	sprintf(t, "%u", link_connect_time);
        tree_addnode(sid, "session_time", t);

	sprintf(t, "%u", link_stats.bytes_in);
        tree_addnode(sid, "session_traffic_in", t);
    
	sprintf(t, "%u", link_stats.bytes_out);
        tree_addnode(sid, "session_traffic_out", t);    
    }
    
    tree_getxml(sid, msg, LENGTH_MSG);
    tree_free(sid);

    if ((socket = open_command_socket(rstate.request_socket, NULL, 0)) == -1) {
	lcp_close(0, "User %s: permission denied - error open socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    if (send_msg(socket, msg) == -1) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error send to socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    bzero(msg, LENGTH_MSG);
    if (recv_msg(socket, msg, LENGTH_MSG) == -1) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error recv to socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }
    
    close_command_socket(socket);

    argv[0]  = strdup("iface_down.sh");
    argv[1]  = strdup(ifname);
    argv[2]  = NULL;
    status = exec_prog("iface_down.sh", rstate.path_to_scripts, argv);
    free(argv[1]);
    free(argv[0]);
    
    if (status == 0 ) info("script running 'iface_down.sh' - success");
    else error("script running 'iface_down.sh' - error");

}

static void
ipstat_interim(void *ignored)
{
    ipcp_options *ho = &ipcp_hisoptions[0];
    int 	socket, ret;
    char 	ip[18];
    char 	msgerr[255];
    XML_SESSION	*sid;
    char	msg[LENGTH_MSG], t[50];
    
    
    if ((sid = tree_init())==NULL) {
	lcp_close(0, "User %s: permission denied - error create xml tree", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }
    
    tree_addnode(sid, "cmd", "interim");
    tree_addnode(sid, "session_id", rstate.SID);

    sprintf(t, "%u", rstate.ip_addr);
    tree_addnode(sid, "framed_address", t);
    if (*rstate.mac) tree_addnode(sid, "mac", rstate.mac);
    if (*ipparam) tree_addnode(sid, "remote_number", ipparam);

    update_link_stats(0);
    if (link_stats_valid) {    
	sprintf(t, "%u", link_connect_time);
        tree_addnode(sid, "session_time", t);

	sprintf(t, "%u", link_stats.bytes_in);
        tree_addnode(sid, "session_traffic_in", t);
    
	sprintf(t, "%u", link_stats.bytes_out);
        tree_addnode(sid, "session_traffic_out", t);    
    }
    
    tree_getxml(sid, msg, LENGTH_MSG);
    tree_free(sid);

    if ((socket = open_command_socket(rstate.request_socket, NULL, 0)) == -1) {
	lcp_close(0, "User %s: permission denied - error open socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    if (send_msg(socket, msg) == -1) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error send to socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    bzero(msg, LENGTH_MSG);
    if (recv_msg(socket, msg, LENGTH_MSG) == -1) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error recv to socket", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }

    if (!ipstat_setparams(msg)) {
	close_command_socket(socket);
	lcp_close(0, "User %s: permission denied - error setparam", user);       /* Close connection */
        status = EXIT_FATAL_ERROR;
	return;
    }
    
    close_command_socket(socket);
    TIMEOUT(ipstat_interim, NULL, 60);
}


static int
ipstat_allowed_address(u_int32_t addr)
{
    ipcp_options *wo = &ipcp_wantoptions[0];
    if (!rstate.choose_ip) {
        if (rstate.any_ip_addr_ok) {
            return 1;
        }
	if (wo->hisaddr != 0 && wo->hisaddr == addr) {
	   return 1;
	}
								                                                                                                                                                                    
	return 0;
    }
    if (addr == rstate.ip_addr) return 1;
    return 0;
}

static int
ipstat_setparams(char *buffer)
{
    XML_SESSION	*sid;
    char	buf[1024];
    u_int32_t	remote;
    
    if (rstate.ipstat_debug) info("xml=%s", buffer);
    if ((sid = xpath_init(buffer)) == NULL) return false;

	if (!xpath_get_param(sid, "error_code", buf, 4)) {
            xpath_free(sid);
	    error("error to xpath_get_param (/query/error_code)");  
            return false;
	}

	if (strncmp(buf, "ERR", 3) == 0) {
	    xpath_free(sid);
	    error("error to IPStat - ERR");  
            return false;
	}

	if (!xpath_get_param(sid, "session_id", rstate.SID, _MAX_LENGTH_SID)) {
	    xpath_free(sid);  
	    error("error to xpath_get_param (/query/session_id)");  
	    return false;
	}
	
	if (xpath_get_param(sid, "session_timeout", buf, 32)) {
	    maxconnect = atol(buf);
	if (maxconnect > 0) TIMEOUT(connect_time_expired, 0, maxconnect);


	}
	if (xpath_get_param(sid, "session_octets_limit", buf, 50)) {
	    maxoctets = atol(buf);
#ifdef MAXOCTETS
	    if (maxoctets > 0) TIMEOUT(check_maxoctets, NULL, maxoctets_timeout);
#endif

	}
	if (xpath_get_param(sid, "octets_direction", buf, 50)) {
	    maxoctets_dir = atol(buf);
	}
	if (xpath_get_param(sid, "shaping_rate", buf, 50)) {
	    int 	status;
	    char 	tmp[255];
	    char 	*argv[5];
	    double	tmp_d;
	    
	    tmp_d = atol(buf)/1024;
	    
	    sprintf(tmp, "%5.2fkbit", tmp_d);
	    argv[0]  = strdup("set_shaper.sh");
	    argv[1]  = strdup(ifname);
	    argv[2]  = strdup(tmp);
	    argv[3]  = NULL;
	    status = exec_prog("set_shaper.sh", rstate.path_to_scripts, argv);
	    free(argv[2]); free(argv[1]);
	    free(argv[0]);
	    
	    if (status == 0 ) info("shaper success");
	    else error("shaper error");
	}
	if (xpath_get_param(sid, "framed_address", buf, _MAX_LENGTH_IP)) {
	    remote = atoll(buf);
	    rstate.choose_ip = 1;
            rstate.ip_addr = remote;
	}
    xpath_free(sid);
    return true;
}
