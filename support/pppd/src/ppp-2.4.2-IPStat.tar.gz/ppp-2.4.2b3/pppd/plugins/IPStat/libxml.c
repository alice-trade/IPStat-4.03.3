#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>

#include "libxml.h"

#ifndef _GNU_SOURCE
 #define _GNU_SOURCE
#endif
#include <string.h>

static void	traverse(gpointer data, gpointer user_data);
static void	parse_arg(char *buffer, int *argc, char *argv[], int max_tok, const char *delim);
static gint	compare(gconstpointer a, gconstpointer b);

typedef struct st_xml_node
{
    char	key[XML_LENGTH_KEY];
    char	value[XML_LENGTH_VALUE];
} XML_NODE;
                                                                                        
XML_SESSION
*xpath_init(const char *buffer) 
{
    XML_SESSION *sid = NULL;
    char	*ptr;
    char	*argv[50];
    int		argc, i;
    
    if ((sid = (XML_SESSION *) g_malloc0(sizeof(XML_SESSION)))==NULL) {
	return NULL;
    }
    
    sid->list = NULL;
    
    if ((ptr = (char*) g_malloc0(strlen(buffer)))==NULL) {
	g_free(sid);
	return NULL;
    }
	strncpy(ptr, buffer, strlen(buffer));
    
	parse_arg(ptr, &argc, argv, 49, "\n");
	    for(i=0;i<argc;i++){
		char		tmp[XML_LENGTH], *t;
		XML_NODE	*node;
		
		strncpy(tmp, argv[i], XML_LENGTH-1);
		if ((t = strchr(tmp, '=')) != NULL) {
		    *t++ = '\0';
		    if ((node = g_malloc0(sizeof(XML_NODE)))!=NULL){
    			strncpy(node->key, tmp, XML_LENGTH_KEY-1);
			strncpy(node->value, t, XML_LENGTH_VALUE-1);
			fprintf(stderr, "key=%s value=%s\n", node->key, node->value);
			sid->list = g_slist_append(sid->list, node);
		    }
		}
	    }
	for(i=0;i<argc;i++) free(argv[i]);
    g_free(ptr);
    
    return sid;
}

gboolean 
xpath_free(XML_SESSION *sid) 
{
    GSList  *t_tek, *t_tmp = (GSList*) sid->list;
    
    while ((t_tek = t_tmp) != NULL) {
	t_tmp = g_slist_next(t_tmp);
        if (t_tek->data) g_free(t_tek->data);
    }
    g_slist_free(sid->list);
    sid->list = NULL;
    
    g_free(sid);
    sid = NULL;
	
    return 1;
}

gboolean
xpath_get_param(XML_SESSION *sid, const char *key, char *value, size_t size_value)
{
    GSList	*ptr;
    XML_NODE	node;
    
    strncpy(node.key, key, XML_LENGTH_KEY);
    bzero(value, size_value);
    
    ptr = g_slist_find_custom(sid->list, &node, compare);
    if (ptr) {
	XML_NODE *t_node = (XML_NODE*) ptr->data;
	strncpy(value, t_node->value, size_value);
	return 1;
    }
    
    return 0;
}

XML_SESSION
*tree_init(void) 
{
	XML_SESSION *sid = NULL;

	if ((sid = (XML_SESSION *) g_malloc0(sizeof(XML_SESSION)))==NULL) {
		return NULL;
	}
	sid->list = NULL;
	
	return sid;
}

gboolean 
tree_free(XML_SESSION *sid) 
{
    GSList  *t_tek, *t_tmp = (GSList*) sid->list;
    
    while ((t_tek = t_tmp) != NULL) {
	t_tmp = g_slist_next(t_tmp);
        if (t_tek->data) g_free(t_tek->data);
    }
    g_slist_free(sid->list);
    sid->list = NULL;
    if (sid) g_free(sid);
    sid = NULL;
	
    return 1;
}

gboolean		
tree_addnode(XML_SESSION *sid, char *name, char *value)
{
    XML_NODE	*node;
        
    if ((node = g_malloc0(sizeof(XML_NODE)))==NULL) return 0;
    
    strncpy(node->key, name, XML_LENGTH_KEY-1);
    strncpy(node->value, value, XML_LENGTH_VALUE-1);
    sid->list = g_slist_append(sid->list, node);
    return 1;
}

gboolean		
tree_getxml(XML_SESSION *sid, char *ptr, int size)
{
    bzero(ptr, size);
    g_slist_foreach(sid->list, traverse, ptr);
    return 1;
}

static void
traverse(gpointer data, gpointer user_data)
{
    XML_NODE 		*node = (XML_NODE*) data;
    unsigned char 	*ptr = (unsigned char*) user_data;
    char		buffer[1024];
    
    sprintf(buffer, "%s=%s\n", node->key, node->value);
    strcat((char*)ptr, buffer);
}

static gint
compare(gconstpointer a, gconstpointer b)
{
    XML_NODE  *node1 = (XML_NODE*) a;
    XML_NODE  *node2 = (XML_NODE*) b;
        
    return (gint) strncmp(node1->key, node2->key, XML_LENGTH_KEY-1);
}

static void 
parse_arg(char *buffer, int *argc, char *argv[], int max_tok, const char *delim)
{
    int         i = 0;
    char        *ptr;
                 
    if (!*buffer) {
	*argc = 0;
	return;
    }
    ptr = strtok(buffer, delim);
    argv[i++] = strdup(ptr);
                                                                                
    while ((ptr = strtok('\0', delim))!=NULL) {
	if (i>max_tok) break;
        argv[i++] = strdup(ptr);
    }

    *argc = i;
    return;
}
