#ifndef _MISC_H
#define _MISC_H

#include <time.h>
#include <sys/types.h>

int	open_command_socket(const char *name_socket, const char *host, const int port);
int	close_command_socket(int sock);

int	send_msg(int sock, char *msg);
int	recv_msg(int sock, char *msg, size_t len);

int	ip2host(uint32_t ip, char *host);
uint32_t host2ip(char *host);
void 	ip2mac(char *ip, char *mac);

int	exec_prog(const char *name, const char *path, char *var[]);

#endif /* misc.h */
